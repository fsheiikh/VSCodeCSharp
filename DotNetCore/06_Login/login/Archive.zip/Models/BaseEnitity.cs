namespace DapperApp.Models {
    public abstract class BaseEntity {
        
    }
}