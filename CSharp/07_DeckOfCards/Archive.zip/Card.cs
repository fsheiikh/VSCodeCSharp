using System;
using System.Collections.Generic;
using System.Linq;

namespace ConsoleApplication
{
    public class Card
    {
        public string value {get; set;}
        public string suit {get; set;}
        public string name {get; set;}
        public int numerical_value {get; set;}

    }
}
